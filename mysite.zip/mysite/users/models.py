from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class UserProfile(models.Model):
    #用户基本信息（名字，密码，邮箱。。。）
    user=models.OneToOneField(User,on_delete=models.CASCADE,related_name='profile')
    org=models.CharField('Organization',max_length=50)
    telephone=models.CharField('telephone',max_length=20,blank=True)
    mod_date=models.DateTimeField('Last modified',auto_now=True)
    class Meta:
        verbose_name='User profile'

    def __str__(self):
        return self.user